package com.java.project.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.java.project.beans.Booking;
import com.java.project.beans.Room;
import com.java.project.beans.Status;

public class RoomDAOImpl implements RoomDAO {

	private JdbcTemplate jdbcTemplate;
	
	public RoomDAOImpl(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public String generateRoomId() throws ClassNotFoundException, SQLException {

	 list();
	Room room=new Room();
	String rid = room.getRoomid();
	int id =Integer.parseInt(rid.substring(1));
	id++;
	if (id >=1 && id <=9) {
	rid = "R00"+id;
	}
	if (id >=10 && id <=99) {
	rid="R0" +id;
	}
	if (id >=100 && id <= 999) {
	rid="R"+id;
	}
	return rid;
	}
	
	@Override
	public List<Room> list() {
		 String sql = "select case when max(RoomID) is NULL then 'R001' else max(RoomID) END rid from Room";
		    List<Room> listContact = jdbcTemplate.query(sql, new RowMapper<Room>() {
		        @Override
		        public Room mapRow(ResultSet rs, int rowNum) throws SQLException {
		            Room room = new Room();
		 room.setRoomid(rs.getString("RoomID"));
		 room.setType(rs.getString("Type"));
		 room.setStatus(Status.valueOf(rs.getString("Status")));
		 room.setCostperday(rs.getInt("CostPerDay"));         
		 
		            return room;
		        }
		 
		    });
		 
		    return listContact;
	}
	

	
	@Override
	public void addRoom(Room room) {
        String cmd="insert into Room(RoomID,Type,Status,"
        		+ "CostPerDay) values(?,?,?,?)";
        jdbcTemplate.update(cmd,room.getRoomid(),room.getType(),
        		room.getStatus().toString(),room.getCostperday());
		
	}

	@Override
	public void addBooking(Booking book) {
		String cmd="insert into Booking(BookId,RoomID,CustName,City,"
				+ " BookDate, ChkInDate,ChkOutDate) values(?,?,?,?,?,?,?)";
		jdbcTemplate.update(cmd,book.getBookID(),book.getRoomID(),book.getCustName(),
				book.getCity(),book.getBookDate(),book.getChkInDate(),book.getChkOutDate());
		
	}

}