package com.java.project.beans;

import java.sql.Date;

public class Booking {
	private String bookID;
	private String roomID;
	private String custName;
	private String city;
	private Date bookDate;
	private Date  chkInDate;
	private Date chkOutDate;
	
	
	
	public String getBookID() {
		return bookID;
	}
	public void setBookID(String bookID) {
		this.bookID = bookID;
	}
	public String getRoomID() {
		return roomID;
	}
	public void setRoomID(String roomID) {
		this.roomID = roomID;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Date getBookDate() {
		return bookDate;
	}
	public void setBookDate(Date bookDate) {
		this.bookDate = bookDate;
	}
	public Date getChkInDate() {
		return chkInDate;
	}
	public void setChkInDate(Date chkInDate) {
		this.chkInDate = chkInDate;
	}
	public Date getChkOutDate() {
		return chkOutDate;
	}
	public void setChkOutDate(Date chkOutDate) {
		this.chkOutDate = chkOutDate;
	}
	
	

}
