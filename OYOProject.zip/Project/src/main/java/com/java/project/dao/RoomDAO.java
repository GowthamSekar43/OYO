package com.java.project.dao;

import java.util.List;

import com.java.project.beans.Booking;
import com.java.project.beans.Room;

public interface RoomDAO {
	List<Room> list();
	void addRoom(Room room);
	void addBooking(Booking book);
}
