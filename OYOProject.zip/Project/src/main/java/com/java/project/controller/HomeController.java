package com.java.project.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.java.project.beans.Room;
import com.java.project.dao.RoomDAO;

@Controller
public class HomeController {

	@Autowired
	
	private RoomDAO roomDAO;
	

	
	@RequestMapping(value = "/saveroom", method = RequestMethod.POST)
	public ModelAndView saveroom(@ModelAttribute Room room) {
	roomDAO.addRoom(room);
	return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/newroom", method = RequestMethod.GET)
	public ModelAndView addroom(ModelAndView model) {
	Room room = new Room();
	model.addObject("Room", room);
	model.setViewName("roomform");
	return model;
	}
	@RequestMapping(value="/")
	public ModelAndView listRoom(ModelAndView model) throws IOException{
	List<Room> listRoom = roomDAO.list();
	model.addObject("listRoom", listRoom);
	model.setViewName("home");
	return model;
	}
}
