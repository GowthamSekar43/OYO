package com.java.project.beans;

public enum Status {
AVAILABLE,BOOKED
}
